# Snake
Simple Snake game in C# using Windows Forms.
![Gameplay](/screenshots/screen.png?raw=true)
